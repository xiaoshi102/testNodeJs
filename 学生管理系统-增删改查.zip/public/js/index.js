$('.glyphicon-trash').click(function(){
	//获取删除学生的id,通过id删除这条数据
	var id = $(this).data('id')
	console.log(id)
	//获取删除学生的name,用作提醒
	var name  = $(this).data('name')
	console.log(name)
	$('#myModal .modal-body').text('点击确认将要删除  ' + name)
	$('#myModal').modal('show')
	//点击确认按钮,执行删除操作
	$('.btn-danger').click(function(){
		$.get('/remove/' + id ,function(responseData){
			//使用友好url给服务器发送数据
			if(responseData.result == 0){
				alert('删除失败,请重试')
			}else{
				//重新加载主页
//				location.href = '/'
				location.reload()  //刷新
			}
		})
	})
	
})









