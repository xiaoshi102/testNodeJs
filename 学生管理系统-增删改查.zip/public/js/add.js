//点击添加学生页面的提交按钮
$('form').submit(function(event){
	event.preventDefault()
	
	$.post('/add', $('form').serialize() , function(responseData){
		console.log(responseData)
		if(responseData.result == 1){
			//数据保存到数据库成功
			location.href = '/'
		}else{
			alert('添加失败,请重试')
		}
	})
})








