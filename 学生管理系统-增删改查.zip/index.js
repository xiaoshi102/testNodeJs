//node服务器基本结构
var express = require('express')
var bodyParser = require('body-parser')
var template = require('art-template')

var app = express()

app.use(express.static('public'))
app.use(bodyParser.urlencoded({extended:false}))

app.engine('.html',template.__express)
app.set('view engine','html')

template.config('cache',false)

//主页
app.use(require('./routes/index'))
//添加学生
app.use(require('./routes/add'))
//删除学生
app.use(require('./routes/remove'))
//修改学生
app.use(require('./routes/update'))


app.listen(5000,function(){
	console.log('running')
})

























