//这是处理主页请求的模块
var express = require('express')
var router = express.Router()
var Student = require('./Student')

//请求主页
router.get('/',function(request,response){
	//从数据库中取出数据,无条件查询
	Student.find().exec(function(error,dataArray){
		if(error){
			//跳转到错误页面,提醒用户重新载入
		}else{
			console.log(dataArray)  //是一个数组
			
			
			dataArray = dataArray.map(function(item){
				//获取item的_id属性
				console.log(typeof item._id)
				//_id属性是 object类型的字段,所以
				//在art-template模版中获取不到_id属性
				//所以,可以在这里把_id的类型转换为字符串
				item.id = item._id.toString()
				//删除 _id
				delete item._id ;
				console.log(item.id)
				return item;
			})
			
			
			//用模板拼接主页,返回给浏览器
			response.render('index',{
				data : dataArray ,
				title : '学生信息管理系统',
				header : '学生查询及管理'
			})
		}
	})
})

module.exports = router







