//编辑修改数据的模块
var express = require('express')
var router = express.Router()

var Student = require('./Student')

//请求编辑数据的页面
router.get('/edit/:id',function(request,response){
	var id = request.params.id ;
	//根据ID获取编辑页面中需要显示的学生信息
	Student.findById(id).exec(function(error,data){
		if(error){
			//跳转到错误页面
		}else{
			console.log(data)
			response.render('edit',{
				data : data ,
				title : '修改信息',
				header : '修改学生信息'
			})
		}
	})
	
	
})

//处理修改数据的请求
router.post('/update/:id',function(request,response){
	var id = request.params.id;
	var data = request.body;
	console.log(id)
	console.log(data)
	//根据id找到对应的数据,进行修改
	Student.findByIdAndUpdate(id,data,function(error){
		if(error){
			//跳转到错误页面
		}else{
			//数据是表单默认提交过来的,所以返回的响应数据不会被监听到
			//所以就不返回数据了, 直接重定向到主页
			response.redirect('/')
		}
	})
})






module.exports = router
