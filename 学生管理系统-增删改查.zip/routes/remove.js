//执行删除操作的模块
var express = require('express')
var router = express.Router()

var Student = require('./Student')

router.get('/remove/:id',function(request,response){
	//获取要删除的数据的ID
	var id = request.params.id ;
	console.log(id)
	//通过id从数据库中删除数据
	Student.findByIdAndRemove(id,function(error){
		if(error){
			response.json({
				result: 0
			})
		}else{
			response.json({
				result: 1
			})
		}
	})
	
})




module.exports = router




