//这是处理添加学生页面请求的模块
var express = require('express')
var router = express.Router()

//请求添加学生页面
router.get('/add.html',function(request,response){
	//用模板拼接添加页面,返回给浏览器
	response.render('add',{
		title : '添加学生',
		header : '添加学生'
	})
})

//请求存储数据
var Student = require('./Student')
router.post('/add',function(request,response){
	var student = new Student(request.body)
	console.log(student)
	//把数据保存到数据库
	student.save(function(error){
		if(!error){
			response.json({
				result : 1
			})
		}else{
			response.json({
				result : 0
			})
		}
	})
})


module.exports = router







