//这个模块是操作数据库共用的内容
//主要任务是建立与studentDB数据库的连接,并获取模型
var mongoose = require('mongoose')
mongoose.connect('mongodb://localhost/studentDB')
var db = mongoose.connection;
db.on('error',function(){
	console.log('链接数据库失败')
})

db.once('open',function(){
	console.log('打开数据库成功')
})


	var schema = mongoose.Schema({
		name : String ,
		age : Number ,
		phone : Number,
		email : String,
		introduce : String 
	})
	
	var Student  = mongoose.model('info',schema)
	

	//导出,代表数据库集合的构造函数
	module.exports = Student

